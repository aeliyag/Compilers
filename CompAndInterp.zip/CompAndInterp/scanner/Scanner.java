package scanner;
import java.io.*;

/**
 * Scanner is a simple scanner for Compilers and Interpreters (2014-2015) lab exercise 1
 * @author Aeliya Grover with guidance from Mrs. Datar
 * @version January 26 2024
 *  
 * Usage:
 * The Scanner takes in a file of elements and goes character by character to identify 
 * lexemes to split and organize the elements on file. These lexemes are characterized by tokens
 * letters, numbers,and operators. These tokens are then returned for the user to use.
 *
 */

public class Scanner
{
    private static BufferedReader in;
    private static char currentChar;
    private static boolean eof;
    
    private static char[] operandList = {'=', '+', '-', '*', '/', '%', '(',  ')','>', '<',':' ,';'};
    private static char[] whiteSpaceList = { ' ', '\t',  '\r', '\n'};
    
    /**
    * Scanner constructor for construction of a scanner that 
    * uses an InputStream object for input.  
    * Usage: 
    * FileInputStream inStream = new FileInputStream(new File(<file name>);
    * Scanner lex = new Scanner(inStream);
    * @param inStream the input stream to use
    */
    public Scanner(InputStream inStream)
    {
        in = new BufferedReader(new InputStreamReader(inStream));
        eof = false;
        getNextChar();
    }
    /**
    * Scanner constructor for constructing a scanner that 
    * scans a given input string.  It sets the end-of-file flag an then reads
    * the first character of the input string into the instance field currentChar.
    * Usage: Scanner lex = new Scanner(input_string);
    * @param inString the string to scan
    */
    public Scanner(String inString)
    {
        in = new BufferedReader(new StringReader(inString));
        eof = false;
        getNextChar();
    }
    /**
    * Method: getNextChar
    * Looks at the next element in the list and turns it into a character for processing
    * There is the potential to get an error if the inputed value is invalad. 
    */
    private static void getNextChar()
    {
        try
        {
            int cur = in.read();
            if (cur == -1) 
                eof = true;
            else
                 currentChar = (char) cur;
        }
        catch (IOException error)
        {
            error.printStackTrace();
            System.exit(-1);
        } 
    }
    /**
    * Method: hasNext
    * Helper method to assess if the file continues
    * @return true if there is another element, false if not
    */
    public static boolean hasNext()
    {
        return !(eof);
    }
 
    /**
    * Method: eat
    * Checks if the parameter matches the current character type 
    * If so, it goes to the next element in the list If not, it throws and exception
    * @param expected character with character type to compare to
    * @throws error if inputed character doesn't match exepcted
    */

    private static void eat(char expected) throws ScanErrorException
    {
        if (currentChar == expected)
        {
            getNextChar(); 
        } 
        else 
        {
            throw new ScanErrorException("Illegal char: " + expected + ". Needed:" + currentChar);
        }
    } 

    /**
    * Note Method: nextTokenreturns a String representing the lexeme
       found. The method nextToken should return the value "END" if the input stream is at end-
       of-file when nextToken is called.
    * @return the token of the specific kind
    * @throws ScanErrorException if element doesn't match with expected
    */
    public String nextToken() throws ScanErrorException //throws ScanErrorException
    {
       
        if(!(hasNext()) || currentChar == '.')
        {
            return "eof";
        }
      
        while (hasNext() && isWhiteSpace(currentChar))
        {
            eat(currentChar);
        }
        if (currentChar == '/' && !isLineComment())
        {

            return "/";
        }
        if (isDigit(currentChar))
        {
       
            return scanNumber();
        }
        else if (isLetter(currentChar))
        {

            return scanIdentifier();
        
        }
        else if (currentChar == ',')
        {
            eat(currentChar); 
            return ",";

        }
        else if (isOperant(currentChar))
        {

            return scanOperand(); 
      
        }
        else  if(!(hasNext()) || currentChar == '.')
        {
            return "eof";
        }
        else
        {
            eat(currentChar);
            return ("Not an element it can input " + currentChar);  
        } 
       
    }    
    
    /*
    * Keeps scaning numbers to help from the token.
    * @return the lexicon of number
    * @throw error if not a number
    * @precondition currentChar is a number
    */
    private static String scanNumber() throws ScanErrorException
    {
        String lex = "";
       
        while (hasNext() && isDigit(currentChar))
        {
            lex += currentChar;
            eat(currentChar);
        }
       
        return lex;
    }
    /*
    * Keeps scaning letters to help from the token.
    * @return lexicon of identifyer
    * @throws exception if char is not an identifier
    * @precondition currentChar is a identifier
    */
    private static String scanIdentifier() throws ScanErrorException
    {
        String lex = "";
       
        while (hasNext() && (isLetter(currentChar)|| isDigit(currentChar)))
        {
            lex += currentChar;
            eat(currentChar);
        }
        return lex;
    }
    /*
    * only a specific type of operant
    * @return lexicon of operands
    * @throws expection if character type doesn't match
    * @precondition currentChar is a operand
    */
    private static String scanOperand() throws ScanErrorException
    {
        char save = currentChar;
        String lex = "";
        lex += save + "";
        eat(currentChar);
       
        if (isOperant(save, currentChar)) 
        {
            lex += currentChar + "";
            eat(currentChar);
        }
        return lex + "";
    }
    
    /*
    * Checks if the parameter is within the list of digits
    * @return true if in range; false if out.
    * @param digit to check
    */
    public static boolean isDigit(char check)
    {
        return check >= '0' && check <= '9';
    }

    /*
    * Checks if in range [a-z, A-Z]
    * @param check letter to check
    * @returns true if in range, false otherwise
    */
    public static boolean isLetter(char check)
    {
        return (check >= 'a' && check <= 'z') || (check >= 'A' && check <= 'Z');
    }

    /*
    * Checks if in range [‘ ‘ ‘\t’ ‘\r’ ‘\n’]
    * @return true if white space, false otherwise
    * @param check character to identify
    */
    public static boolean isWhiteSpace(char check)       
    {
        boolean has = false; 

        for (int i = 0; i < whiteSpaceList.length; i++)
        {
            if (whiteSpaceList[i] == check)
            {
                has = true;
            }
        }
        return has;
    }
    /**
    * Takes in two parameters and determines if the operant is two elements wide.
    * @return true if operant is two character wide; false if not.
    * @param first the parameter that comes first
    * @param next the parameter that comes after
    */
    public static boolean isOperant(char first, char next)
    {
        boolean val = false;
       
       
        if(first == ':' && currentChar == '=' )
        {
            val = true; 
        }
       
       
        if(first == '<' && currentChar == '=')
        {
            val = true;
        }
       
        if(first == '>' && currentChar == '=')
        {
            val = true;
        }
        if(first == '<' && currentChar == '>')
        {
            val = true;
        }

        return val;
       
    }
    /*
    * Checks if character is in the operant list
    * @return has true if an operator, false if otherwise
    * @param check character if operator
    */
    public static boolean isOperant(char check)
    {
        boolean has = false; 
       
        for (int i =0; i < operandList.length; i++)
        {
            if (operandList[i] == check)
            {
                has = true;
            }
        }
        return has;
    }
    
    /**
     * Determines if the line is a line comment and deleats if so
     * @return true if it is a line comment, false if not
     * @throws ScanErrorException
     */
    public static boolean isLineComment() throws ScanErrorException
    {
        char save = currentChar;
        eat(currentChar);
        if (save == '/' && currentChar == '/') 
        {

            while (hasNext() && !(currentChar == '\n'))
            {
                eat(currentChar);
            }
            eat(currentChar);
            return true;
        }
        return false;
       
    }
  
}

