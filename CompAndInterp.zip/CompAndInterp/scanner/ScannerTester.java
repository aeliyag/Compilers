package scanner;

//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
//import java.io.InputStream;

public class ScannerTester {

    public static void main(String[] args) throws ScanErrorException, IOException 
    {
        // TODO Auto-generated method stub

        FileReader start = new FileReader("/Users/24aeliyag/Downloads/chipotleData.txt");

        Scanner tester = new Scanner(start);
        System.out.println(tester.nextToken());
        while(!(tester.yyatEOF()))
        {
            System.out.println(tester.nextToken());
        }

        
     
  



        

    }

}
