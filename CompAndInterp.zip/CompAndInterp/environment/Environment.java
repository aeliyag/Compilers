package environment;

import java.util.HashMap;
import java.util.Map;

import ast.ProcedureDeclaration;

/**
 * Creates the Enviornment for the AST and Parser
 * @author  Aeliya Grover
 * @version March 25th 2024
 */
public class Environment 
{
    private Map <String, Integer> vars;
    private Map <String, ProcedureDeclaration> procedures; 
    private Environment parent;


    /**
     * Initalizes parent instatnce variables
     */
    public Environment()
    {
        vars = new HashMap <String, Integer>();
        procedures = new HashMap <String, ProcedureDeclaration>();
        parent = null;
    } 
    /**
     * Initalize Instance Variable
     * @param  parent
     */
    public Environment(Environment parent)
    {
        vars = new HashMap <String, Integer>();
        procedures = new HashMap <String, ProcedureDeclaration>();
        this.parent = parent;

    }
    /**
     * Sorts through to set variable in appropriate enviornemnt
     * @param variable
     * @param value
     */
    public void setVariable(String variable, int value)
    {
        //System.out.println("Setting  " + variable + " value " + value);
        Environment temp = this;
        while (temp != null)
        {
            if (temp.vars.containsKey(variable))
            {
                temp.vars.put(variable, value);
                return;
            }
            else 
                temp = temp.getParent();


        }
        vars.put(variable, value);

    }

    /**
     * Gives the value of the varaible in the HashMap
     * @param variable
     * @return value of the variables
     * @precondition parent is not null
     */
    public int getVariable(String variable)
    {
        //System.out.println("Looking for " + variable);
        Environment temp = this;
        while (temp != null)
        {
            if(temp.vars.containsKey(variable))
            {
                //System.out.println("Found " + temp.vars.get(variable));
                return temp.vars.get(variable);
            }
            else 
            {
                temp = temp.getParent();
            }

        }
        //System.out.println("not found");
        return 0;
        
    }
    /**
     * Sets procedure in appropriate envrionemnt
     * @param name
     * @param declaration
     */
    public void setProcedure(String name, ProcedureDeclaration declaration)
    {
        if (parent != null)
            parent.setProcedure(name, declaration);
        else 
            procedures.put(name, declaration);
    }


    /**
     * Retrieves the procedure in the environment 
     * @param name
     * @return procedure of given name
     */
    public ProcedureDeclaration getProcedure(String name)
    {
        Environment temp = this; 
        while (temp.getParent() != null)
        {
            temp = temp.getParent();
        }
        return temp.procedures.get(name);
    }

    /**
     * Gives the parent Environment
     * @return  parent
     */
    public Environment getParent()
    {
        return parent;
    }

    /**
     * puts variable in current environemnt
     * @param variable
     * @param value
     */
    public void declareVariable(String variable, int value)
    {
        vars.put(variable, value);
    }


}
