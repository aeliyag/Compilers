package parser;

import java.util.ArrayList;

import java.io.IOException;
import java.util.List;

import ast.Assignment;
import ast.BinOp;
import ast.Block;
import ast.Condition;
import ast.Expression;
import ast.If;
import ast.Variable;
import ast.While;
import ast.Number;
import ast.ProcedureCall;
import ast.ProcedureDeclaration;
import ast.Program;
import ast.Statement;
import ast.Writeln;
import scanner.*;
/**
 * Parser takes a stream of tokens and determines if they are syntactically correct. 
 * @author Aeliya Grover with help from Mrs. Datar and Claire Su
 * @version March 10 2024
 *  
 * Usage:
 * The parser goes token by token to ensure the tokens are arranged and
 * follow proper grammer. The parser is ab//le to parse and claculate through arthmatic sequences.
 */
public class Parser 
{

    private Scanner save;
    private String currToken, error;
    //private Map <String, Expression> vars;

    /**
     * Constructor for the parser class. 
     * Takes in a Scanner file and gets the first token ready for parsing.
     * Initalizes the Map for storing variables
     * @param scan  tokens to parse through
     * @throws IOException
     * @throws ScanErrorException
     * @precondition Scanner works to parse through and create a string of tokens
     * @postcondition currToken has the first token and instance variables are intialized
     */
    public Parser(Scanner scan) throws IOException, ScanErrorException
    {
        save = scan;
        currToken = "" + save.nextToken();
       // vars  = new HashMap<String, Expression>();
    }
    
    /**
     * The expected token matches the current token. 
     * It will move through the Scanner file to the next Token
     * 
     * @param expectedToken the expected token the currentToken is
     * @throws IOException
     * @throws ScanErrorException
     * @precondition currToken is updated and expected Token is properly passed through
     * @postcondition code continues with the next token in line
     */
    private void eat(String expectedToken) throws IOException, ScanErrorException
    {
        if (currToken.equals(expectedToken))
        {
            //System.out.println(currToken);
            currToken = save.nextToken();
            
        }
        else
        {
            error = "Current Token: " + currToken + " Expected: " + expectedToken; 
            throw new IllegalArgumentException(error); //error is to solve char length requirement
        }

    }
    /**
     * Checks if the current character is a number. 
     * Returns if it is. 
     * @return parsed number
     * @throws IOException from eat method
     * @throws ScanErrorException from eat method
     * @precondition the currentToken in a number
     * @postcondition the parse continues if the currToken is a number and next token is identified
     */
    private Number parseNumber() throws IOException, ScanErrorException 
    {
        
        int num = Integer.parseInt(currToken);
        
        eat(currToken);
        return new Number(num);
    }

    /**
     * Finds the value of the ID in the Map
     * @return the value of the ID
     * @throws IOException from eat method
     * @throws ScanErrorException from eat method
     * @precondition the currentToken is an ID
     * @postcondition the currenToken is confirmed an ID and next Token is identified
     */
    private Expression parseId() throws IOException, ScanErrorException
    {
        Expression id = new Variable(currToken);
        eat(currToken);
        return id;
    }


    /**
     * Parses through a program support for procedures
     * Takes in a global set of variables for CodeGen
     * @return  properly parsed program
     * @throws IOException
     * @throws ScanErrorException
     */
    public Program parseProgram() throws IOException, ScanErrorException
    {
        List<String> programVariables = new ArrayList<>();
        List<ProcedureDeclaration> procedureDeclarations = new ArrayList<>();
        
        if(currToken.equals("VAR"))
        {
            eat("VAR");
            if (!currToken.equals(";"))
            {
                programVariables.add(currToken);
                eat(currToken);
                while (currToken.equals(","))
                {
                    eat(",");
                    programVariables.add(currToken);
                    eat(currToken);
                }

            }
            eat(";");

        }

        while (currToken.equals("PROCEDURE"))
        {
            eat("PROCEDURE");
            ProcedureDeclaration dec = parseProcedureDecleration();
            procedureDeclarations.add(dec);
        }
        
        Statement main = parseStatement(); 

        return new Program(programVariables, procedureDeclarations, main);
        
    }

    /**
     * Sorts through syntax of procedure declaration
     * @return properly parsed procedure declration
     * @throws IOException
     * @throws ScanErrorException
     */
    public ProcedureDeclaration parseProcedureDecleration() throws IOException, ScanErrorException
    {
        String procedureName = currToken;
        eat(currToken);
        List<String> params = new ArrayList<>();
        //System.out.println("here " + currToken);
        eat("(");
        if (!currToken.equals(")"))
        {
            params.add(currToken);
            eat(currToken);
            while (currToken.equals(","))
            {
                eat(",");
                params.add(currToken);
                eat(currToken);
            }

        }
        eat(")");
        eat(";");
        Statement body = parseStatement(); 
        return new ProcedureDeclaration(procedureName, body, params);

    }

    /**
     * Checkes syntax of a procedure call
     * @param name
     * @return Procedure Call object
     * @throws IOException
     * @throws ScanErrorException
     */
    public ProcedureCall parseProcedureCall(String name) throws IOException, ScanErrorException
    {
        
        eat("(");
        List<Expression> params = new ArrayList<>();
        if (!currToken.equals(")"))
        {
            params.add(parseExpr());
        
            while (currToken.equals(","))
            {
                eat(",");
                params.add(parseExpr());
            }

        }
        eat(")");
      //  eat(";");
        return new ProcedureCall(name, params);

    }

    /**
     * Parses the statement to check if it needs to print something, start a BEGIN sequence, 
     * evaluate an if statement or while statement
     * or save a variable name
     * 
     * @throws IOException from eat method
     * @throws ScanErrorException from eat method
     * @return Statement object to later evaluate
     * @precondition the current token is the start of a statement
     * @postcondition the statement is parsed and ready to be solved
     */
    public Statement parseStatement() throws IOException, ScanErrorException 
    {
        String curr = currToken;
        
       
        if (curr.equals("WRITELN")) 
        {
            eat("WRITELN");
            eat("(");
            Expression exp = parseExpr();
            eat(")");
            eat(";");
            return new Writeln(exp);
        } 
        else if (curr.equals("BEGIN")) 
        {

            eat("BEGIN");
            List<Statement> stmts = new ArrayList<>(); 
            stmts = whileBegin(stmts);

            return new Block(stmts);

        }
        else if (curr.equals("IF"))
        {
            eat("IF");
            Expression exp1 = parseExpr(); 
            String relop = currToken; 
            eat(currToken);
            Condition cond = new Condition(exp1, relop, parseExpr());
            eat("THEN");
            Statement stmt = parseStatement(); 


            return new If(cond, stmt);

        }
        else if (curr.equals("WHILE"))
        {
            eat("WHILE");
            Expression exp1 = parseExpr(); 
            String relop = currToken; 
            eat(currToken);
            Condition cond = new Condition(exp1, relop, parseExpr());
            eat("DO");
            Statement stmt = parseStatement(); 
            return new While(cond, stmt);

        }
        else // detemrines if it is a ID
        {
            String var = currToken;
            eat(currToken);
            
            eat(":=");
            
            Expression exp = parseExpr();
            //vars.put(var, exp);
            
            
            eat(";");
            return new Assignment(var, exp);
        }

    }
   
    /**
     * Helper method for BEGIN statement END;
     * 
     * @throws IOException        from eat method
     * @throws ScanErrorException from eat method
     * @param stmts to store all the statements
     * @return List<Statement> to be evaluated later
     * @precondition current token is inside BEGIN...END
     * @postcondition current token is outside BEGIN...END
     */
    public List<Statement> whileBegin(List<Statement> stmts) throws IOException, ScanErrorException 
    {

        String newcurr = currToken;
        if (newcurr.equals("END")) 
        {
            eat("END");
            eat(";");
        } 
        else 
        {
            stmts.add(parseStatement());
            stmts = whileBegin(stmts);

        }
        return stmts;
    }


    /**
     * Serches for the negative sign, brackets, IDs, and numbers
     * @return the parsed factor
     * @throws IOException from eat method
     * @throws ScanErrorException from eat method
     * @precondition token is the start of a Factor 
     * @postcondition token is after the factor 
     */
    public Expression parseFactor() throws IOException, ScanErrorException
    {
        String factor = currToken; 
        //eat(currToken);
        Expression num;
        //System.out.println(vars.containsKey(currToken));
        if (factor.equals("-"))
        {
            //System.out.print(currToken);
            eat(currToken);
            num = new BinOp("-", new Number(0), parseFactor());
            return num;
        }
        else if (factor.equals("("))
        {
            //System.out.print(currToken);
            eat(currToken); 
            num = parseExpr(); 
            //System.out.print(currToken);
            eat(")");
            return num;
        }
        else if (isIdentifer(factor))
        {
            
            Expression exp = parseId();
            if(currToken.equals("("))
            {
                
                num = parseProcedureCall(factor);
                return num;
            }
            else
            {
                return exp;
            }
        }
        else 
        { 
            num = parseNumber();
            return num;
        }
    }


    /**
     * Determines if token is an identifer
     * @param token
     * @return  true if it is, false otherwise
     */
    public boolean isIdentifer(String token)
    {
        return Character.isLetter(token.charAt(0));
    }




    /**
     * Parses the Term by checking if the tokens equal * or /
     * Evaluates the Terms properly according to program grammer
     * @return value of the term
     * @throws IOException from eat method
     * @throws ScanErrorException from eat method
     * @precondition current token is the start of the term 
     * @postcondition current token is after the term 
     */
    public Expression parseTerm() throws IOException, ScanErrorException
    {
        Expression num = parseFactor();
      
        while (currToken.equals("*") || currToken.equals("/"))
        {
            if (currToken.equals("*"))
            {
                eat("*");
                num = new BinOp("*", num, parseFactor());
                //System.out.print("*");
                //num *= parseFactor();  
                
            }
            else if (currToken.equals("/"))
            {
                eat("/"); 
                num = new BinOp("/", num, parseFactor());
                //System.out.print("/");
                //num /= parseFactor(); 
            }
    
        }  
        
        return num;
    }
    /**
     * Follows proper grammer to check if the token is a + or a - and parse the Expression
     * @return number result of the parsed Expression
     * @throws IOException from eat method
     * @throws ScanErrorException from eat method
     * @precondition the current token is the start of a expression
     * @postcondition the current token is after the expression
     */
    public Expression parseExpr() throws IOException, ScanErrorException
    {
        Expression num = parseTerm();
        

        while (currToken.equals("+") || currToken.equals("-"))
        {
            if (currToken.equals("+"))
            {
                eat("+");
                num = new BinOp("+", num, parseTerm());
                //System.out.print("+");
               // num += parseTerm();  
                
            }
            else if (currToken.equals("-"))
            {
                eat("-"); 
                num = new BinOp("-", num, parseTerm());
                //System.out.print("-");
                //num -= parseTerm(); 
            }
    
        }  
        
        return num;
    }

}
