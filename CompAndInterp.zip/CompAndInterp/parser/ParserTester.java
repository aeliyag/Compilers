package parser;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import ast.Evaluator;
import ast.Program;
import environment.Environment;
import scanner.*;

/**
 * Tests the Parser and AST class
 * @author Aeliya Grover
 * @version March 25th 2024
 */
public class ParserTester 
{

    /**
     * Runs the tester
     * @param args
     * @throws IOException
     * @throws ScanErrorException
     */
    public static void main(String[] args) throws IOException, ScanErrorException
    {
        String file = "/Users/24aeliyag/Desktop/CompAndInterp/parserTest0.txt";
        File start = new File(file);

        FileInputStream test = new FileInputStream(start);
        Scanner scan = new Scanner(test);
        Parser tester = new Parser(scan);
        Program thread = tester.parseProgram();
        Evaluator solve = new Evaluator();
        Environment envi = new Environment();
        solve.exec(thread, envi);
        thread.compile("tester.s");

        
        
    }
    
}
