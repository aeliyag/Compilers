package ast;


/**
 * Abstract class for Expressions
 * @author Aeliya Grover
 * @version March 25th
 */
public abstract class Expression
{
    /**
     * Parent method for compile
     * @param e
     */
    public void compile(Emitter e)
    {
        throw new RuntimeException("Implement me!!!!!");
    }
}

