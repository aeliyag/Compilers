package ast;

import java.util.List;

/**
 * Stores infomration about program
 * @author  Aeliya Grover
 * @version April 16th 2024
 */
public class Program 
{
    private List<String> variables;
    private List<ProcedureDeclaration> procedures; 
    private Statement stmt; 

    /**
     * Initalizes instance variables
     * @param procedures
     * @param stmt
     * @param variables
     */
    public Program (List<String> variables, List<ProcedureDeclaration> procedures, Statement stmt)
    {
        this.procedures = procedures; 
        this.stmt = stmt;
        this.variables = variables;
    }

    /**
     * Gives the procedure declarations list of the program
     * @return procedures
     */
    public List<ProcedureDeclaration> getProcedureDeclarations()
    {
        return procedures;
    }

    /**
     * Gives the statement in procedure 
     * @return stmt
     */
    public Statement getStatement()
    {
        return stmt;
    }

    /**
     * Gives list of variables 
     * @return variables
     */
    public List<String> getVariables()
    {
        return variables;
    }


    /**
     * sets up core outline for emitter
     * @param name
     * @postcondition proper program is ready for execution in generated code
     * @Override 
     */
    public void compile (String name)
    {
        Emitter e = new Emitter(name);
        e.emit(" # @author Aeliya Grover");
        e.emit(" # @version May 14th");
        e.emit(".data");
        for (String var: variables)
        {
            e.emit("var"+ var + ": .word 0");
        }
        e.emit(" newLine:  .asciiz  \"\\n\" ");
        e.emit(".text");
        e.emit(".globl main");
        e.emit("main:");
        stmt.compile(e);
        e.emit("li $v0 10");
        e.emit("syscall");
        e.close();
    }

}
