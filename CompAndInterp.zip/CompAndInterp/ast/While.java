package ast;
/**
 * Object for the While construct 
 * Saves proper instance variables
 * @author Aeliya Grover
 * @version March 25 2024
 */
public class While extends Statement
{

    private Condition cond;
    private Statement stmt;
    /**
     * initializes the instance variables
     * @precondition While has been parsed and is syntactically accurate
     * @postcondition instance variables are saved
     * @param cond
     * @param stmt
     */
    public While(Condition cond, Statement stmt)
    {
        this.cond = cond; 
        this.stmt = stmt;
    }

    /**
     * Gives the condition for the while statement
     * @return cond
     */
    public Condition getCondition()
    {
        return cond;

    }

    /**
     * Gives the statement in the while loop
     * @return stmt
     */
    public Statement getStatement()
    {
        return stmt;
    }
    /**
     * Writes a while loop with escap ready
     * @param e Emitter
     * @postcondition proper while loop is ready for execution in generated code
     * @Override 
     */
    public void compile (Emitter e)
    {
        int labelId = e.nextLabelId(); 
        String loop = "loop" + labelId;
        String end = "endloop" + labelId;
        e.emit(loop + ":");
        cond.compile(e, end);
        stmt.compile(e);
        e.emit("j " + loop);
        e.emit(end + ":");



    }
}
