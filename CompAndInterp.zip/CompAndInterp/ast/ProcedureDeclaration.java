package ast;

import java.util.List;

/**
 * Saves important infomration for a procedure declaration
 * @author  Aeliya Grover
 * @version April 16 2024
 */
public class ProcedureDeclaration extends Statement
{
    private String name; 
    private List<String> parameters; 
    private Statement body; 
     
    /**
     * Initalizes the instance variables
     * @param name
     * @param body
     * @param parameters
     */
    public ProcedureDeclaration(String name, Statement body, List<String> parameters)
    {
        this.name = name;
        this.parameters = parameters;
        this.body = body;
    }

    /**
     * Gives the name of procedure
     * @return name
     */
    public String getName() 
    {
        return name;
    }

    /**
     * Gives the body of procedure
     * @return body
     */
    public Statement getStatement()
    {
        return body;
    }

    /**
     * Gives list of parameter names
     * @return parameters
     */
    public List<String> getParameters()
    {
        return parameters;
    }

}
