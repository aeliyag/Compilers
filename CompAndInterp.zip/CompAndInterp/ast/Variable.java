package ast;

/**
 * Varaible constsruct with variable name
 * @author Aeliya Grover
 * @version March 25th 2024
 */
public class Variable extends Expression 
{
    private String name; 

    /**
     * Initalizing the Instance variable
     * @precondition Variable has been parsed and is syntactically accurate
     * @postcondition instance variables are saved
     * @param name
     */
    public Variable(String name)
    {
        this.name = name;
    }

    /**
     * Gives the name of the variable
     * @return name
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Writes a variable to stack 
     * @param e Emitter
     * @postcondition proper variable is ready for execution in generated code
     * @Override 
     */
    public void compile (Emitter e)
    {
        e.emit("la $t0 var" + name);
        e.emit("lw $v0 ($t0)");
    }

    
}
