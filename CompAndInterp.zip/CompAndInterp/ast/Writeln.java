package ast;

/**
 * Stores proper information to execute a Writeln statement
 * @author Aeliya Grover
 * @version March 25th 2024
 */
public class Writeln extends Statement 
{
    private Expression exp; 
    /**
     * Declares the instance variable
     * @precondition Writeln has been parsed and is syntactically accurate
     * @postcondition instance variables are saved
     * @param exp
     */
    public Writeln(Expression exp)
    {
        this.exp = exp;
    }
    /**
     * Gives the saved Expression to print 
     * @return  exp
     */
    public Expression getExpression()
    {
        return exp;
    }

    /**
     * Compiles the expression then transfers to $a0 and prints
     * @param e Emitter
     * @postcondition proper print statement is ready for execution
     * @Override 
     */
    public void compile (Emitter e)
    {
        exp.compile(e);
        e.emit("move $a0 $v0");
        e.emit("li $v0 1");
        e.emit("syscall");
        e.emit("li $v0  4");
        e.emit("la $a0  newLine");
        e.emit("syscall");

    }

  
}
