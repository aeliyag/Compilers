package ast;


/**
 * Saves proper information for a Binary Operator expression
 * @author Aeliya Grover
 * @version March 25th 2024
 */
public class BinOp extends Expression
{
    private String op; 
    private Expression exp1; 
    private Expression exp2; 

    /**
     * Initalizes the instance variables
     * @precondition BinOp has been parsed and is syntactically accurate
     * @postcondition instance variables are saved
     * @param op
     * @param exp1
     * @param exp2
     */
    public BinOp(String op, Expression exp1, Expression exp2)
    {
        this.op = op; 
        this.exp1 = exp1; 
        this.exp2 = exp2; 

    }

    /**
     * Gives the operator for the expression
     * @return op
     */
    public String getOp()
    {
        return op;
    }
    /**
     * Gives the first expression
     * @return exp1
     */
    public Expression getExp1()
    {
        return exp1; 
    }

    /**
     * Gives the second expression
     * @return exp2
     */
    public Expression getExp2()
    {
        return exp2;
    }

    /**
     * compiles expressions on both sides and then determines what
     * kind of operation to do. 
     * @param e Emitter environment
     * @postcondition proper binOp is ready for execution in generated code
     * @Override 
     */
    public void compile(Emitter e)
    {
        exp1.compile(e);
        e.emitPush("$v0");

        exp2.compile(e);
        e.emitPop("$t0");

        if (op.equals("+"))
        {
            e.emit("addu $v0 $v0 $t0");
        }
        else if (op.equals("-"))
        {
            e.emit("subu $v0 $t0 $v0");
        }
        else if (op.equals("*"))
        {
            e.emit("mult $t0 $v0");
            e.emit("mflo $v0");
        }
        else if (op.equals("/"))
        {
            e.emit("div $t0 $v0");
            e.emit("mflo $v0");
        }

    }




}
