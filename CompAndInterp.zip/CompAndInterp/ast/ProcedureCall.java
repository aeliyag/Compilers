package ast;

import java.util.List;

/**
 * Saves appropriate information for a procedure call
 * @author Aeliya Grover
 * @version April 16 2024
 */
public class ProcedureCall extends Expression
{
    private String name; 
    private List<Expression> args; 


    /**
     * Initializes instance variables
     * @param name  name of method
     * @param args  arguments
     */
    public ProcedureCall (String name, List<Expression> args)
    {
        this.name = name; 
        this.args = args; 
    }

    /**
     * Gives the name of procedure
     * @return name
     */
    public String getName()
    {
        return name;
    }

    /**
     * Gives the procedure arguemnts
     * @return args
     */
    public List<Expression> getArguments()
    {
        return args;
    }
    
}
