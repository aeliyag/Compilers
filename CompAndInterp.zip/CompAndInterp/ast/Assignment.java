package ast;

/**
 * Creates a construct for Assignment 
 * @author Aeliya Grover
 * @version March 25 2024
 */
public class Assignment extends Statement
{
    private String var; 
    private Expression exp; 

    /**
     * Initializes instance variables
     * @precondition Assingnment has been parsed and is syntactically accurate
     * @postcondition instance variables are saved
     * @param var
     * @param exp
     */
    public Assignment(String var, Expression exp)
    {
        this.var = var; 
        this.exp = exp;
    }

    /**
     * Gives the variable needing to be assigned
     * @return var
     */
    public String getVar()
    {
        return var;
    }

    /**
     * Gives the expression for the assignment
     * @return exp
     */
    public Expression getExp()
    {
        return exp;
    }

    /**
     * Compiles the expression and assigns it to the variable
     * @param e Emitter
     * @postcondition variable is properly saved
     * @Override 
     */
    public void compile (Emitter e)
    {
        exp.compile(e); 
        e.emit("la $t0 var" + var);
        e.emit("sw $v0 ($t0)");
    }

}
