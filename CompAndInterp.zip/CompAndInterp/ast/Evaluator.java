package ast;

import java.util.List;

import environment.Environment;

/**
 * Takes Statements and Expressions and evalutes the end result 
 * @author Aeliya Grover
 * @version March 25th 2024
 */
public class Evaluator 
{

    /**
     * Prepares method by declaring it in environemnt and executing remaining code
     * @param prog program to evaluate
     * @param env envionrment to evaluate in
     * @precondition code is parsed properly 
     * @postcondition program declaration is set up
     */
    public void exec(Program prog, Environment env)   //$$$ how to make a hanging class for this
    {
        List<ProcedureDeclaration> declarations = prog.getProcedureDeclarations(); 
        Environment global = new Environment(env);  



        for (int i = 0; i < declarations.size(); i++)
        {
            exec(declarations.get(i), global);
            
        }

        Statement main = prog.getStatement(); 
        exec(main, global);

    }

    /**
     * Places a procedure in an environemnt
     * @param dec proceudre declaration to place in environment
     * @param env environment to place into
     */
    public void exec(ProcedureDeclaration dec, Environment env)
    {
        //System.out.print(dec.getName());
        env.setProcedure(dec.getName(), dec); 
    }
    



    
    /**
     * Categorizes the type of Statement to execute
     * @param stmt Statement to execute
     * @param env environemtn to execute statement in
     */
    public void exec(Statement stmt, Environment env)
    {
        if(stmt instanceof Block)
            exec( (Block) stmt, env);
        else if(stmt instanceof Assignment)
            exec( (Assignment) stmt, env);
        else if(stmt instanceof Writeln)
            exec( (Writeln) stmt, env);
        else if (stmt instanceof If)
            exec((If) stmt, env);
        else if (stmt instanceof While)
            exec((While) stmt, env);

    }
    /**
     * Determines the proper expression to evaluate
     * @param exp 
     * @param env
     * @return num
     */
    public int eval(Expression exp, Environment env) 
    {
        int num = 0;
        if(exp instanceof BinOp)
            num = eval((BinOp) exp, env);
        else if(exp instanceof Variable)
            num = eval((Variable) exp, env);
        else if(exp instanceof Number)
            num = eval((Number) exp, env);
        else if (exp instanceof ProcedureCall)
            num = eval( (ProcedureCall) exp, env);
            
        
        return num;

    }

    /**
     * Evaluates the code of a procedure when it is called
     * @param call
     * @param env
     * @return procedure return value variable
     */
    public int eval(ProcedureCall call, Environment env)
    {
        String name = call.getName(); 
        List<Expression> arguments = call.getArguments();
        
        //System.out.println("Looking for " + name);
        ProcedureDeclaration dec = env.getProcedure(name);
        List<String> param = dec.getParameters();

        //Step 1
        Environment subEnvironment = new Environment(env);  
        
        subEnvironment.declareVariable(name, 0);

        // Step 2
        for (int i = 0; i < arguments.size(); i++)    
        {
            Expression arg = arguments.get(i);
            String parameter = param.get(i);
            subEnvironment.declareVariable(parameter, eval(arg, env));

        }
        // Step 3
        exec(dec.getStatement(), subEnvironment); 
        
        //Step 4
        return subEnvironment.getVariable(name);
        
    }
    

    /**
     * Evaluates a While loop
     * @param stmt
     * @param env
     */
    public void exec (While stmt, Environment env)
    {
        Condition con = stmt.getCondition();

        while(eval(con, env))
        {
            exec(stmt.getStatement(), env);
        }
    }

    /**
     * Executes a if statement
     * @param stmt
     * @param env
     */
    public void exec( If stmt, Environment env)
    {
        Condition con = stmt.getCondition();
        Boolean execute = eval(con, env);

        if(execute)
        {
            exec(stmt.getStatement(), env);
        }

    }
    /**
     * Evaluates a condition statement
     * @param cond
     * @param env
     * @return result
     */
    public boolean eval(Condition cond, Environment env)
    {
        Expression exp1 = cond.getExp1();
        Expression exp2 = cond.getExp2();
        String relop = cond.getRelop(); 

        int val1 = eval(exp1, env);
        int val2 = eval(exp2, env);

        boolean result;

        if (relop.equals("=")) 
        {
            result = val1 == val2;
        } 
        else if (relop.equals("<>")) 
        {
            result = val1 != val2;
        } 
        else if (relop.equals("<")) 
        {
            result = val1 < val2;
        } 
        else if (relop.equals(">")) 
        {
            result = val1 > val2;
        } 
        else if (relop.equals("<=")) 
        {
            result = val1 <= val2;
        } 
        else if (relop.equals(">=")) 
        {
            result = val1 >= val2;
        } 
        else 
        {
            throw new IllegalArgumentException("Invalid operator: " + relop);
        }

        return result;

    }


    /**
     * Executes a writeln statement 
     * @param stmt
     * @param env
     */
    public void exec(Writeln stmt, Environment env)
    {
        System.out.println(eval(stmt.getExpression(), env));   
    }

    /**
     * Executes an assignment
     * @param assign
     * @param env
     */
    public void exec(Assignment assign , Environment env)
    {
        Expression exp = assign.getExp();
        String varName = assign.getVar();

        env.setVariable(varName, eval(exp, env));
    }

    /**
     * Executes a Block of statements
     * @param stmts
     * @param env
     */
    public void exec(Block stmts, Environment env)
    {
        List<Statement> run = stmts.getStmts();
        int length = run.size(); 
        for (int i = 0; i < length; i++)
        {
            exec(run.get(i), env);
        }

    }

    /**
     * Evalues a binary operator expression
     * @param binop
     * @param env
     * @return the result of the binop expression
     */
    public int eval(BinOp binop, Environment env)
    {
        String op = binop.getOp();
        Expression exp1 = binop.getExp1();
        Expression exp2 = binop.getExp2();
        if (op.equals("-"))
        {
            return eval(exp1, env) - eval(exp2, env);
        }
        else if (op.equals("+"))
        {
            return eval(exp1,env) + eval(exp2, env);
        }
        else if (op.equals("*"))
        {
            return eval(exp1,env) * eval(exp2, env);
        }
        else 
        {
            return eval(exp1,env) / eval(exp2, env);
        }
       

    }

    /**
     * Evaluates the value of the variable inputted
     * @param var
     * @param env
     * @return value of the variable
     */
    public int eval(Variable var, Environment env)
    {
        return env.getVariable(var.getName());
        
    }

    /**
     * Gives the number saved
     * @param num
     * @param env
     * @return value of the num
     */
    public int eval(Number num, Environment env) 
    {
        return num.getValue();
    }




   
}
