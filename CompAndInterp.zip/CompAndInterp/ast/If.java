package ast;

/**
 * Stores proper variables for the If Statement construct
 * @author Aeliya Grover
 * @version March 25th
 */
public class If extends Statement
{
    private Condition cond; 
    private Statement stmt;

    /**
     * Initializes the instance varaibles
     * @precondition If Statement has been parsed and is syntactically accurate
     * @postcondition instance variables are saved
     * @param cond
     * @param stmt
     */
    public If (Condition cond, Statement stmt)
    {
        this.cond = cond; 
        this.stmt = stmt;

    }
    
    /**
     * Gives the condition of the statement
     * @return cond
     */
    public Condition getCondition()
    {
        return cond;
    }

    /**
     * Gives the statement of the if statement
     * @return stmt
     */
    public Statement getStatement()
    {
        return stmt;
    }

    /**
     * Determines name of end label and writes the proper conditional to file
     * @param e Emitter environment
     * @postcondition proper if statement is ready for execution in generated code
     * @Override 
     */
    public void compile (Emitter e)
    {
        int labelID = e.nextLabelId(); 
        String endIf = "endif" + labelID; 

        cond.compile(e, endIf);
        stmt.compile(e); 
        e.emit(endIf + ":");


    }
}
