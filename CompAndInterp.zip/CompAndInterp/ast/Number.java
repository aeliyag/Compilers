package ast;
/**
 * Saves the values of a number construct
 * @author Aeliya Grover
 * @version March 25th 2024
 */
public class Number extends Expression
{
    private int value; 

    /**
     * Initalizes the instance variables
     * @precondition Number has been parsed and is syntactically accurate
     * @postcondition instance variables are saved
     * @param value
     */
    public Number(int value)
    {
        this.value = value;
    }

    /**
     * Gives the value of the number
     * @return value
     */
    public int getValue()
    {
        return value;
    }

    /**
     * Loads current value to $v0
     * @param e Emitter
     * @postcondition proper number is ready for execution in generated code
     * @Override 
     */
    public void compile(Emitter e)
    {
        e.emit("li $v0 " + value);
    }


    
}
