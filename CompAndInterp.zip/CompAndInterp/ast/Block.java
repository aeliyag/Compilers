package ast;

import java.util.List;

/**
 * Saves the proper variables for a BLock construct
 * @author Aeliya Grove
 * @version March 25th 2024 
 */
public class Block extends Statement
{
    private List<Statement> stmts; 

    /**
     * Initalizes the instance variables
     * @precondition Block has been parsed and is syntactically accurate
     * @postcondition instance variables are saved
     * @param stmts
     */
    public Block(List<Statement> stmts)
    {
        this.stmts = stmts;
    }
    /**
     * Gives the list of statmenets saved in the Block
     * @return stmts
     */
    public List<Statement> getStmts()
    {
        return stmts;
    }

    /**
     * Compiles a block of statements
     * @param e Emitter
     * @postcondition proper block is ready for execution in generated code
     * @Override 
     */
    public void compile(Emitter e)
    {
        for(Statement statements: stmts)
        {
            statements.compile(e);
        }

    }
    
}
