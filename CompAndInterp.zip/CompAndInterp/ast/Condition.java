package ast;

/**
 * Stores and gives information relating to conditions 
 * @author Aeliya Grover
 * @version March 25 2024
 */
public class Condition 
{
    private Expression exp1; 
    private String relop; 
    private Expression exp2;

    /**
     * Initalizes the instance variables
     * @precondition Condition has been parsed and is syntactically accurate
     * @postcondition instance variables are saved
     * @param exp1 first expression
     * @param relop operator
     * @param exp2 second expression
     */
    public Condition(Expression exp1, String relop, Expression exp2)
    {
        this.exp1 = exp1; 
        this.relop = relop; 
        this.exp2 = exp2; 
    }
    
    /**
     * Gives the first expression to compare to the second
     * @return exp1
     */
    public Expression getExp1()
    {
        return exp1;
    }
    
    /**
     * Gives the operator in between the two expressions
     * @return relop
     */
    public String getRelop()
    {
        return relop;
    }

    /**
     * Gives the second expression to compare to the first expression
     * @return exp2
     */
    public Expression getExp2()
    {
        return exp2;
    }

    /**
     * Compiles both expressions and determines what operation to do and write
     * to the Emitter class
     * @param e
     * @param targetLabel label to jump to if false
     * @postcondition proper condition is ready for execution in generated code
     * @Override 
     */
    public void compile(Emitter e, String targetLabel)
    {
        exp1.compile(e);
        e.emitPush("$v0");
        exp2.compile(e);
        e.emitPop("$t0");
        if (relop.equals("<"))
        {
            e.emit("bge $t0 $v0 " + targetLabel);
        }
        else if (relop.equals("<="))
        {
            e.emit("bgt $t0 $v0 " + targetLabel);
        }
        else if (relop.equals(">"))
        {
            e.emit("ble $t0 $v0 " + targetLabel);
        }
        else if (relop.equals(">="))
        {
            e.emit("blt $t0 $v0 " + targetLabel);
        }
        else if (relop.equals("="))
        {
            e.emit("bne $t0 $v0 " + targetLabel);
        }
        else if (relop.equals("<>"))
        {
            e.emit("beq $t0 $v0 " + targetLabel);
        }
        


    }

}
