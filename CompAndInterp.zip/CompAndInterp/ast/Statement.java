package ast;


/**
 * Abstract class for Statements
 * @author Aeliya Grover
 * @version March 25th 2024
 */
public abstract class Statement
{
    /**
     * Parent compile method 
     * @param e
     */
    public void compile(Emitter e)
    {
        throw new RuntimeException("Implement me!!!!!");
    }
}
