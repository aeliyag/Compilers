package ast;
import java.io.*;

public class Emitter
{
    private PrintWriter out;
    private int labelId;

	//creates an emitter for writing to a new file with given name
    public Emitter(String outputFileName)
    {
        try
        {
            out = new PrintWriter(new FileWriter(outputFileName), true);
        }
        catch(IOException e)
        {
            throw new RuntimeException(e);
        }
    }

	//prints one line of code to file (with non-labels indented)
    public void emit(String code)
    {
    	if (!code.endsWith(":"))
			code = "\t" + code;
        out.println(code);
    }

	//closes the file.  should be called after all calls to emit.
    public void close()
    {
        out.close();
    }

    /**
     * Places the value in a given regester on the stack
     * @param reg
     * @postcondition proper push is ready for execution in generated code
     */
    public void emitPush(String reg)
    {
        emit("subu $sp $sp 4 #push to " +reg);

        emit("sw " + reg + " ($sp)");

    }
    
    /**
     * Takes a value of the stack and places it in the given regester
     * @param reg
     * @postcondition proper pop is ready for execution in generated code
     */
    public void emitPop(String reg)
    {
        emit("lw " + reg + " ($sp)  #return value in "+reg);
        emit("add $sp $sp 4");

    }
    
    /**
     * increments the labelID and returns the counter
     * @return labelID
     * @postcondition label is incremented by 1
     */
    public int nextLabelId()
    {
        labelId++;
        return labelId;
    }

}